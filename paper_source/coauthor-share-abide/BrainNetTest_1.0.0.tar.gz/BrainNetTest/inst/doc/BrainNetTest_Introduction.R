## ----setup_intro, include = FALSE---------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## -----------------------------------------------------------------------------
library("BrainNetTest")

group_a <- generate_category_graphs(
  n_graphs = 12,
  n_nodes = 8,
  n_communities = 2,
  base_intra_prob = 0.8,
  base_inter_prob = 0.1,
  seed = 1
)
group_b <- generate_category_graphs(
  n_graphs = 12,
  n_nodes = 8,
  n_communities = 2,
  base_intra_prob = 0.4,
  base_inter_prob = 0.5,
  seed = 2
)

networks <- brainnet_data(
  list(GroupA = group_a, GroupB = group_b),
  node_labels = paste0("Node", seq_len(8)),
  communities = rep(c("Community 1", "Community 2"), each = 4)
)
networks
summary(networks)

## -----------------------------------------------------------------------------
center_a <- central_graph(group_a)
graph_distance(group_a[[1]], center_a)

## -----------------------------------------------------------------------------
result <- brainnet_test(
  networks,
  n_permutations = 199,
  edge_method = "fisher",
  adjust = "holm",
  seed = 42
)

result
summary(result)

## -----------------------------------------------------------------------------
head(as.data.frame(result))
selected_edges(result)
selected_nodes(result)

## -----------------------------------------------------------------------------
result_with_ablation <- brainnet_test(
  networks,
  n_permutations = 99,
  ablation = TRUE,
  seed = 42
)
head(ablation_path(result_with_ablation))

