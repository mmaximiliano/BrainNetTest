## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## -----------------------------------------------------------------------------
library("BrainNetTest")

## -----------------------------------------------------------------------------
community_sizes <- c(5, 5)
graph <- generate_community_graph(
  n_nodes = 10,
  n_communities = 2,
  community_sizes = community_sizes,
  intra_prob = c(0.85, 0.65),
  inter_prob = 0.1,
  seed = 1
)

isSymmetric(graph)
all(diag(graph) == 0)

## -----------------------------------------------------------------------------
group_a <- generate_category_graphs(
  n_graphs = 10,
  n_nodes = 10,
  n_communities = 2,
  community_sizes = community_sizes,
  base_intra_prob = c(0.85, 0.65),
  base_inter_prob = 0.10,
  seed = 11
)
group_b <- generate_category_graphs(
  n_graphs = 10,
  n_nodes = 10,
  n_communities = 2,
  community_sizes = community_sizes,
  base_intra_prob = c(0.55, 0.65),
  base_inter_prob = 0.25,
  seed = 12
)
group_c <- generate_category_graphs(
  n_graphs = 10,
  n_nodes = 10,
  n_communities = 2,
  community_sizes = community_sizes,
  base_intra_prob = c(0.30, 0.65),
  base_inter_prob = 0.45,
  seed = 13
)

networks <- brainnet_data(
  list(GroupA = group_a, GroupB = group_b, GroupC = group_c),
  node_labels = paste0("Region", seq_len(10)),
  communities = rep(c("Module 1", "Module 2"), community_sizes)
)
summary(networks)

## -----------------------------------------------------------------------------
result <- brainnet_test(
  networks,
  n_permutations = 199,
  adjust = "holm",
  seed = 21
)

result
head(as.data.frame(result)[order(as.data.frame(result)$rank), ])
selected_edges(result)

## ----plot, eval = requireNamespace("igraph", quietly = TRUE), fig.width=8, fig.height=8----
plot(result, reference = "GroupA")

## -----------------------------------------------------------------------------
selected_nodes(result)

